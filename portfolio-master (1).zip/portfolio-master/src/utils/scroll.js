import ASScroll from "@ashthornton/asscroll";

export const scroll = () => {
  const asscroll = new ASScroll();
  asscroll.enable();
};
